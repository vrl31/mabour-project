<?php
    $mabour = mysqli_connect("localhost","root","","mabour");
    if(mysqli_connect_errno()) {
        printf("Connenctio info: ", mysqli_connect_error());
    }
?>



